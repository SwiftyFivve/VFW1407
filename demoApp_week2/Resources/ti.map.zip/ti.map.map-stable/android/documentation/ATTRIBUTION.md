## ATTRIBUTION

#### Google Map SDK. 
The use and distribution of Google Map SDK is governed under the Google Terms of Service, as found on <http://www.google.com/intl/en/policies/terms/>.
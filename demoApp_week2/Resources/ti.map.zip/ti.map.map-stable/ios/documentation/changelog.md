# Change Log
<pre>
v2.0.2  Fixed ignoring userLocation property during view creation [TIMOB-12733]

v2.0.1  Fixed annotation not showing leftButton rightButton [TC-3524]

v2.0.0  Fixed methods deprecated in iOS 7 [MOD-1521]
        Add Support for iOS7 MapCamera [MOD-1523]
        Expose new iOS7 properties and methods of MapView [MOD-1522]
        Fixed map view with percentage values become grayed when rotating the screen [MOD-1613]

v1.0.0  Moved out of the Titanium SDK to a standalone module [MOD-1514]